voltpak-hardware-open-source
============================
Licence: CERN Open Hardware Licence v2 - Strongly Reciprocal (CERN-OHL-S)
Released by VoltPak, Inc. -- voltpak.com

WHAT IS INCLUDED
----------------
  /schematics/
    main-inverter-board.kicad_sch
    bms-interface-board.kicad_sch
    usb-pd-controller.kicad_sch

  /pcb/
    main-inverter-board.kicad_pcb
    bms-interface-board.kicad_pcb

  /mechanical/
    voltpak-1000-chassis.step

  /bom/
    bom-main-inverter.csv
    bom-bms-interface.csv

WHAT IS NOT INCLUDED
--------------------
Firmware running on the MCU is proprietary. We do not publish it.
This is our engineering moat.

You are welcome -- and encouraged -- to reverse-engineer it.
Builders who share findings in our Discord (discord.gg/voltpak) receive
hardware, pre-release units, and direct engineering access from our team.

LICENCE SUMMARY
---------------
You may study, modify, and manufacture hardware based on these files provided:
  - You release modifications under CERN-OHL-S.
  - You make source files available when distributing hardware.
  - You retain this attribution.

Full licence: https://ohwr.org/cern_ohl_s_v2.txt
